"""Generate the Phase 2 identity from authored vector geometry.

Requires Python fontTools with WOFF2 support. Normal web builds use the committed
generated assets and do not require Python. Phase 1 assets are never overwritten.
"""
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.fontBuilder import FontBuilder
import json

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'public/brand'
for folder in ['logos', 'fonts', 'proofs']:
    (OUT / folder).mkdir(parents=True, exist_ok=True)
identity = json.loads((ROOT / 'brand/identity.json').read_text())

# Three rounded open loops, spaced around a shared negative center. The former
# joins merged in the Phase 1 drawing. These endpoints sit outside the center.
PETAL = 'M27 28C15 27 8 22 11 14C14 7 23 10 26 16C28 20 29 23 29 25'
SMALL_PETAL = 'M25.5 27C15 26 9 21 12 14C15 8 23 12 26 18C27 20 27.5 22 27.5 23'

def symbol(small=False):
    d = SMALL_PETAL if small else PETAL
    width = 6.4 if small else 6
    return '<g fill="none" stroke="currentColor" stroke-width="'+str(width)+'" stroke-linecap="round">'+''.join(
        f'<path d="{d}" transform="rotate({a} 32 32)"/>' for a in [0, 120, 240])+'</g>'

def wordmark(dot_color=None):
    # User explicitly chose the Phase 1 navbar treatment. Preserve its lowercase
    # Hanken 750, -.04em spacing, and trailing dot. Outline the letters so the
    # finished wordmark has no text nodes, glyph references, or runtime font.
    font = instantiateVariableFont(TTFont(ROOT / 'public/fonts/hanken-grotesk-latin-wght-normal.woff2'), {'wght': 750}, inplace=True)
    glyphs, cmap, x, parts = font.getGlyphSet(), font.getBestCmap(), 0, []
    for letter in 'korner.':
        name = cmap[ord(letter)]
        pen = SVGPathPen(glyphs)
        glyphs[name].draw(pen)
        color = f' fill="{dot_color}"' if letter == '.' and dot_color else ''
        parts.append(f'<path d="{pen.getCommands()}"{color} transform="translate({x * .092:.4f} 68) scale(.092 -.092)"/>')
        x += font['hmtx'].metrics[name][0] - 40
    return '<g fill="currentColor">'+''.join(parts)+'</g>'

def font_paths(text, size, weight=400):
    font = TTFont(ROOT / 'public/fonts/geist-latin.woff2')
    font = instantiateVariableFont(font, {'wght': weight}, inplace=True)
    glyphs = font.getGlyphSet()
    cmap = font.getBestCmap()
    units = font['head'].unitsPerEm
    x = 0
    parts = []
    for letter in text:
        name = cmap[ord(letter)]
        pen = SVGPathPen(glyphs)
        glyphs[name].draw(pen)
        if pen.getCommands():
            parts.append(f'<path d="{pen.getCommands()}" transform="translate({x * size / units:.3f} {size:.3f}) scale({size / units:.6f} {-size / units:.6f})"/>')
        x += font['hmtx'].metrics[name][0]
    return ''.join(parts), x * size / units

def svg(body, viewbox, color, title):
    _, _, width, height = viewbox.split()
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="{viewbox}" fill="currentColor" color="{color}" role="img"><title>{title}</title>{body}</svg>\n'

colors = {'brand': '#B52F52', 'ink': '#30272C', 'white': '#FFFFFF', 'dark': '#F692AA', 'mono': '#000000', 'primary': '#30272C'}
tagline, tagline_width = font_paths(identity['tagline'], 13, 500)
for variant, color in colors.items():
    pieces = {
        'symbol': (f'<g color="{ "#B52F52" if variant == "primary" else color }">{symbol()}</g>', '0 0 64 64'),
        'symbol-small': (f'<g color="{ "#B52F52" if variant == "primary" else color }">{symbol(True)}</g>', '0 0 64 64'),
        'wordmark': (wordmark('#B52F52' if variant == 'primary' else None), '0 0 288 76'),
        'horizontal': (f'<g transform="translate(0 6)" color="{ "#B52F52" if variant == "primary" else color }">{symbol()}</g><g transform="translate(82 0)">{wordmark("#B52F52" if variant == "primary" else None)}</g>', '0 0 370 76'),
        'horizontal-tagline': (f'<g transform="translate(0 6)" color="{ "#B52F52" if variant == "primary" else color }">{symbol()}</g><g transform="translate(82 0)">{wordmark("#B52F52" if variant == "primary" else None)}</g><g transform="translate(86 88)">{tagline}</g>', '0 0 370 110'),
    }
    for name, (body, viewbox) in pieces.items():
        (OUT / f'logos/korner-{name}-{variant}.svg').write_text(svg(body, viewbox, color, f'Korner {name.replace("-", " ")} — {variant}'))

# Full-bleed square masters are submitted to app stores; rounded tiles are
# previews only. Actual symbol ink stays inside the central 70% safe area.
for name, background, foreground, rounded in [
    ('app-icon', '#B52F52', '#FFFFFF', False),
    ('app-icon-dark', '#211A20', '#F692AA', False),
    ('app-icon-preview', '#B52F52', '#FFFFFF', True),
    ('app-icon-dark-preview', '#211A20', '#F692AA', True),
]:
    radius = ' rx="224"' if rounded else ''
    body = f'<rect width="1024" height="1024"{radius} fill="{background}"/><g transform="translate(75 80) scale(12.5)">{symbol()}</g>'
    (OUT / f'logos/korner-{name}.svg').write_text(svg(body, '0 0 1024 1024', foreground, f'Korner {name.replace("-", " ")}'))

# Original one-glyph currency companion. Keep Geist's own font software
# unchanged. The metric frame is inherited; the N and double bars are authored.
geist = TTFont(ROOT / 'public/fonts/geist-latin.woff2')
units = geist['head'].unitsPerEm
assert units == 1000
for weight, stem in [(400, 62), (500, 72), (600, 82), (700, 92)]:
    pen = TTGlyphPen(None)
    def polygon(points):
        # Consistent winding makes overlapped bars add, rather than erase ink.
        pen.moveTo(points[0])
        for p in points[1:]: pen.lineTo(p)
        pen.closePath()
    left, right, top = 80, 520, geist['OS/2'].sCapHeight
    polygon([(left, 0), (left, top), (left + stem, top), (right, stem * 1.8), (right, top), (right + stem, top), (right + stem, 0), (right, 0), (left + stem, top - stem * 1.8), (left + stem, 0)])
    bar = round(stem * .72)
    for y in [258, 424]:
        polygon([(28, y), (28, y + bar), (632, y + bar), (632, y)])
    glyph = pen.glyph()
    blank = TTGlyphPen(None).glyph()
    fb = FontBuilder(units, isTTF=True)
    fb.setupGlyphOrder(['.notdef', 'space', 'naira'])
    fb.setupCharacterMap({32: 'space', 0x20A6: 'naira'})
    fb.setupGlyf({'.notdef': blank, 'space': blank, 'naira': glyph})
    fb.setupHorizontalMetrics({'.notdef': (660, 0), 'space': (250, 0), 'naira': (660, 28)})
    fb.setupHorizontalHeader(ascent=geist['hhea'].ascent, descent=geist['hhea'].descent, lineGap=geist['hhea'].lineGap)
    fb.setupNameTable({'familyName': 'Korner Currency', 'styleName': str(weight), 'uniqueFontIdentifier': f'KornerCurrency-{weight}-1.0', 'fullName': f'Korner Currency {weight}', 'psName': f'KornerCurrency-{weight}', 'version': 'Version 1.0'})
    fb.setupOS2(sTypoAscender=geist['OS/2'].sTypoAscender, sTypoDescender=geist['OS/2'].sTypoDescender, sTypoLineGap=geist['OS/2'].sTypoLineGap, usWinAscent=geist['OS/2'].usWinAscent, usWinDescent=geist['OS/2'].usWinDescent, sxHeight=geist['OS/2'].sxHeight, sCapHeight=top, usWeightClass=weight)
    fb.setupPost()
    fb.font.flavor = 'woff2'
    fb.save(OUT / f'fonts/korner-currency-{weight}.woff2')

(OUT / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
print('Generated 34 logo SVGs, 4 currency font weights, and the identity manifest.')
