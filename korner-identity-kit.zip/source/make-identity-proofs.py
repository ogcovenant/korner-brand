"""Create vector proof sheets and portable asset metadata; no browser screenshots."""
from pathlib import Path
import json, re, importlib.util

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('korner_geometry', ROOT / 'scripts/make-identity.py')
geometry = importlib.util.module_from_spec(spec)
spec.loader.exec_module(geometry)
OUT = ROOT / 'public/brand'

def text(label, x, y, size=18, color='#30272C', weight=400):
    paths, _ = geometry.font_paths(label, size, weight)
    return f'<g fill="{color}" transform="translate({x} {y-size})">{paths}</g>'

def placed(name, x, y, width, height):
    data = (OUT / f'logos/korner-{name}.svg').read_text()
    data = data.replace('<svg ', f'<svg x="{x}" y="{y}" ', 1)
    data = re.sub(r'width="[^"]+"', f'width="{width}"', data, count=1)
    return re.sub(r'height="[^"]+"', f'height="{height}"', data, count=1)

def sheet(body, width, height, title):
    return geometry.svg(f'<rect width="{width}" height="{height}" fill="#FFFFFF"/>{body}', f'0 0 {width} {height}', '#30272C', title)

body = text('A shared center. Space to be yourself.', 40, 52, 30, weight=500)
body += '<rect x="40" y="100" width="240" height="240" fill="#F9F7F7" stroke="#95818C" stroke-dasharray="5 5"/>'
body += '<rect x="80" y="140" width="160" height="160" fill="none" stroke="#E5DCE0"/>'
body += placed('symbol-brand', 80, 140, 160, 160)
body += text('Clear space = 16 units', 40, 380, 18)
body += text('Measured from the 64-unit symbol grid.', 40, 408, 13, '#70606A')
body += text('Dedicated small', 380, 134, 16, weight=500)
body += text('Standard symbol', 550, 134, 16, weight=500)
for x, size, name in [(400,16,'symbol-small-brand'),(570,24,'symbol-brand'),(700,32,'symbol-brand'),(850,64,'symbol-brand')]:
    body += placed(name, x, 196-size/2, size, size)
    body += text(f'{size}px', x, 260, 16)
body += text('Wordmark minimum', 380, 330, 16, weight=500)
body += placed('wordmark-ink', 380, 360, 112, 112*76/288)
body += text('112px wide', 380, 430, 14, '#70606A')
body += text('Horizontal minimum', 650, 330, 16, weight=500)
body += placed('horizontal-primary', 650, 360, 160, 160*76/370)
body += text('160px wide', 650, 430, 14, '#70606A')
body += text('Final proposed minima. Validate the intended display and print conditions.', 40, 488, 14, '#70606A')
(OUT / 'proofs/logo-construction.svg').write_text(sheet(body,1200,520,'Korner clear space and minimum-size proof'))

# Currency proof uses each actual glyph file, not a system font substitute.
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
body = text('Geist + Korner Currency', 40, 50, 30, weight=500)
for index, weight in enumerate([400,500,600,700]):
    x = 40 + (index % 2)*590
    y = 140 + (index // 2)*160
    body += text(f'Weight {weight}', x, y-28, 14, '#70606A')
    currency = TTFont(OUT / f'fonts/korner-currency-{weight}.woff2')
    glyphs = currency.getGlyphSet()
    pen = SVGPathPen(glyphs)
    glyphs['naira'].draw(pen)
    body += f'<path d="{pen.getCommands()}" fill="#30272C" transform="translate({x} {y+40}) scale(.056 -.056)"/>'
    body += text('180,000', x+38, y+40, 56, weight=weight)
body += text('Original currency outlines. Matching 1000-unit frame and cap height; no edits to Geist.',40,422,15,'#70606A')
(OUT / 'proofs/type-currency.svg').write_text(sheet(body,1200,460,'Geist and Korner Currency glyph proof'))

body = '<rect width="1600" height="1000" fill="#F9F7F7"/>'
body += text('Your campus. Your Korner.',64,88,44,weight=500)
body += text('In the loop / Phase 2',1160,82,21,'#70606A')
body += '<rect x="64" y="136" width="1472" height="480" rx="16" fill="#B52F52"/>'
body += placed('horizontal-white',420,292,760,760*76/370)
body += text('Different people. Shared possibilities.',112,566,24,'#FFFFFF')
body += placed('wordmark-primary',100,726,460,460*76/288)
body += placed('app-icon-preview',692,696,176,176)
body += '<rect x="980" y="686" width="556" height="216" rx="12" fill="#211A20"/>'
body += placed('horizontal-dark',1020,760,472,472*76/370)
body += text('Navbar wordmark, retained.',100,916,18,'#70606A')
body += text('Abstract symbol. Familiar name. One coherent identity.',64,970,20,'#70606A')
(OUT / 'proofs/identity-overview.svg').write_text(geometry.svg(body,'0 0 1600 1000','#30272C','Korner In the loop Phase 2 identity overview'))

logos = []
for p in sorted((OUT / 'logos').glob('*.svg')):
    data = p.read_text()
    logos.append({'file':p.name, 'viewBox':re.search(r'viewBox="([^"]+)"',data).group(1), 'purpose':'Preview only; not app-store artwork' if 'preview' in p.name else 'App-store master; platform mask supplies corners' if 'app-icon' in p.name else 'Brand artwork'})
(OUT / 'logo-manifest.json').write_text(json.dumps({'version':'1.0.0','logos':logos},indent=2)+'\n')
print('Created 3 outlined vector proof sheets and logo inventory.')
