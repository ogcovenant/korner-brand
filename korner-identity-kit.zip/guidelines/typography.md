# Korner typography

Phase 2 · In the loop · v1.0 for review.

## Roles

**Geist** is the interface and editorial family. Use a single variable WOFF2 face for headings, body, labels, buttons, and numerals. The system favors legibility and lets the hibiscus identity and symbol provide distinction.

**korner.** is fixed logo artwork based on the navbar lettering the user explicitly liked: Hanken Grotesk 750, −0.04em spacing, with the trailing period. Its SVG contains outlines. Hanken is not a second interface font, and a live font rendering is not a substitute for the approved SVG.

**Korner Currency** is an authored one-glyph ₦ companion. The supplied Geist subsets do not contain U+20A6. Four tiny WOFF2 files supply the missing symbol at weights 400, 500, 600, and 700. Geist's font software is unmodified. The companion uses the same 1000-unit frame and vertical metrics, a 710-unit cap height, and a 660-unit advance. Its source geometry is in `scripts/make-identity.py`.

## Scale

| Role | Mobile / desktop | Line height | Weight | Tracking |
| --- | --- | --- | --- | --- |
| Display | 40 / 64px | 1.05 | 600 | −0.03em |
| Page title | 32 / 40px | 1.15 | 600 | −0.025em |
| Section heading | 24 / 28px | 1.25 | 600 | −0.02em |
| Card title | 16 / 18px | 1.4 | 500 | 0 |
| Body | 16 / 16px | 1.6 | 400 | 0 |
| Secondary | 14 / 14px | 1.5 | 400 | 0 |
| Label / button | 14 / 14px | 1.4 | 600 | 0 |
| Caption | 12 / 12px | 1.5 | 500 | 0.01em |
| Price | 20 / 24px | 1.2 | 600 | −0.02em |

These are product typography specifications. The brand guide can use larger display specimens; its implementation does not establish a production component library. Keep interface labels in sentence case. Reserve 700 for rare emphasis. Do not apply negative tracking to paragraph text.

## Readability and numbers

Default body copy is 16px/1.6. Limit long-form measures to 65–75 characters. Use 14px for genuinely secondary content and 12px for supplemental captions, never as the only explanation of a critical action. Support zoom and wrapping; do not truncate prices or campus names without a way to read them.

Use `font-variant-numeric: tabular-nums` for price lists, balances, and comparisons. Format prices with `Intl.NumberFormat('en-NG', { style: 'currency', currency: 'NGN', maximumFractionDigits: 0 })` when fractional precision is unnecessary. Financial products must separately define their precision requirements. Example prices in the guide are illustrative.

## Font loading proposal

```css
font-family: "Geist", "Korner Currency", Arial, sans-serif;
font-synthesis: none;
font-variant-numeric: tabular-nums; /* prices and comparable figures */
```

Self-host Geist Latin as variable WOFF2 with `font-display: swap`. Preload only the face required above the fold. Add the extended Latin subset with a unicode range for content needing accented Latin characters. Each currency face uses `unicode-range: U+20A6`, so it is requested only where ₦ is present. The four companion weights are static; do not request unsupported intermediate currency weights.

The guide's scoped CSS demonstrates loading. Exporting semantic production typography tokens is Phase 3 work. The font files and licenses are included in the kit. On a slow connection, system fallback remains possible until fonts load; glyph coverage is verified but browser/device alignment still needs contextual testing.

## Proof and attribution

`public/brand/proofs/type-currency.svg` draws each currency glyph from its actual generated font file alongside Geist figures at the same weight. The WOFF2 cmaps, horizontal/vertical metrics, and glyph contours are checked directly. Raster PNG proofs are rendered from that SVG; these are not browser screenshots.

Primary sources: [Geist](https://github.com/vercel/geist-font) and [Hanken Grotesk](https://github.com/marcologous/hanken-grotesk). Their supplied SIL Open Font License notices are retained in the kit. The companion is original project artwork generated as font data; no third-party naira glyph has been copied.
