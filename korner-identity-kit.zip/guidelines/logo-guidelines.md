# Korner logo guidelines

Phase 2 · In the loop · v1.0 for review. Artwork lives in `public/brand/logos/`; the complete inventory is `public/brand/logo-manifest.json`.

## Logo family

| Asset | Use |
| --- | --- |
| `korner-horizontal-primary.svg` | Preferred horizontal: hibiscus symbol, charcoal wordmark, hibiscus dot on a light surface |
| `korner-horizontal-brand.svg` | Single hibiscus horizontal lockup |
| `korner-symbol-brand.svg` | Standard standalone symbol |
| `korner-symbol-small-brand.svg` | Dedicated 16–23px symbol |
| `korner-wordmark-primary.svg` | Navbar treatment: charcoal name and hibiscus dot |
| `korner-wordmark-ink.svg` | Entire wordmark in charcoal |
| `korner-horizontal-tagline-primary.svg` | Parent lockup with outlined primary tagline |
| `korner-app-icon.svg` | Full-bleed 1024-square app icon master |
| `korner-app-icon-dark.svg` | Optional charcoal/rose app icon master |
| `*-preview.svg` | Rounded app icon previews only |

Each symbol, small symbol, wordmark, horizontal, and tagline lockup is also supplied in brand hibiscus, charcoal ink, white, dark-theme rose, and black monochrome versions. The primary two-color family is supplied separately. All files include explicit dimensions, a viewBox, and an accessible title. Lettering and tagline are paths, with no runtime font requirement.

## Clear space

Define **x = 16 units**, one quarter of the standard symbol's 64-unit square grid. Keep at least x clear on all sides of the symbol or complete lockup. For a 32px symbol, x is 8px. For the horizontal logo, calculate x from the 64-unit symbol embedded in the 370-unit-wide lockup: at 185px wide, x is 8px.

Measure outside the supplied SVG frame, not by trimming to the visible ink. Do not place text, images, borders, screen edges, or another mark in that zone. The wordmark-only file uses its 76-unit vertical frame as the reference: reserve 19 source units on each side. At 112px wide, that is approximately 7.4px.

App icons are an exception to external clear space: they have their own safe-area construction and platform mask. Do not add extra padding around an app icon master before platform submission.

## Minimum sizes

| Asset | Digital minimum | Print minimum |
| --- | --- | --- |
| Standard symbol | 24px square | 7mm square |
| Small symbol | 16px square; use only at 16–23px | Use standard print artwork |
| Wordmark | 112px wide | 28mm wide |
| Horizontal | 160px wide | 40mm wide |
| Horizontal with tagline | 280px wide | 70mm wide |

These are the final proposed v1.0 specifications, supported by vector/raster proofs. They are design limits, not evidence of a completed device or press trial. Confirm the intended screen density, substrate, and print process. Below 16px use a text label or another UI affordance rather than compressing the symbol further. Size the SVG proportionally; do not independently assign width and height.

## Approved backgrounds

Primary or hibiscus artwork: white or the approved light canvas. Charcoal ink: light canvas, white, or sand where measured contrast permits. White: hibiscus or approved dark charcoal. Rose: the approved dark canvas or dark surface. Black and white variants support single-color reproduction.

Do not use white on sand, rose on white, or hibiscus on charcoal. Do not place a logo directly over a busy photograph; supply a sufficiently large solid approved field and retain clear space. Use files provided for each context instead of applying arbitrary CSS filters.

## App icons

Use the 1024×1024 square master without pre-rounded corners. The artwork remains inside the central 70% square and fits a centered circular mask. Let the platform supply the final rounded, squircle, or circular crop. Rounded SVGs are presentation previews only. Raster PNGs are supplied in `public/brand/app-icons/`; preserve sRGB, opacity, and square dimensions.

The main app icon uses white on hibiscus in both ordinary interface themes. The optional dark icon is charcoal with a rose mark. Platform-specific asset packaging is outside this branding phase; validate masks on target devices before submission.

## Incorrect use

Do not rotate, stretch, redraw, outline, shadow, or gradient-fill the identity. Do not separate or recolor the three loops independently. Do not replace the wordmark with typed Geist or Hanken text. The period is part of the wordmark; do not remove it, enlarge it, or add a second one. Written prose still uses the name “Korner”.

Keep the symbol-to-wordmark ratio and spacing fixed. Do not attach a university crest, graduation cap, cart, pin, or verification tick. Do not use the logo as a seller trust badge.

## Accessibility and source

Use an appropriate image label such as `alt="Korner"` in a home link. If the same link includes visible “Korner” text, mark the duplicate image decorative with empty alt. Decorative repeat marks should not be announced. The SVG title is helpful but does not replace HTML image alternatives.

Generator: `scripts/make-identity.py`. The original symbol is authored path geometry. The user-chosen navbar wordmark is outlined from the locally supplied licensed Hanken font. Original authorship and licensing do not establish trademark availability; no clearance is claimed.
