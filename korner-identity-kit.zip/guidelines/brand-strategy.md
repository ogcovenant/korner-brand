# Korner brand strategy

Phase 2 · In the loop · Identity v1.0 for review.

## Purpose

Connect the individual corners of campus into a useful shared world. Begin with buying, selling, and trading; retain room for student businesses, services, food, accommodation, events, communities, and financial services.

## Audience and position

Nigerian university students finding what they need from people around them. Korner should feel chosen by students, with the clarity and care expected when money changes hands. Campus proximity is the starting advantage; the identity must remain useful beyond university.

## Identity decisions

The user selected C — In the loop, superseding the Phase 1 recommendation of A. They also explicitly liked the Phase 1 navbar wordmark. The refined system combines the three-loop symbol with the bold lowercase **korner.** navbar treatment, including its tight spacing and trailing dot.

The interface type remains Geist. The wordmark is a fixed, outlined Hanken Grotesk 750 treatment; it is not replaced by live interface text. The signature color is hibiscus. Warm neutral surfaces keep everyday browsing calm.

## Core expression

**Your campus. Your Korner.** Keep the capitalization and two sentences. The dot is part of the visual wordmark; the product's written name remains **Korner**, without a mandatory trailing dot in prose.

Three loops keep their individual space around a shared center. They represent belonging and possibility without restricting the platform to shopping. Their geometry is a metaphor, not a verification badge or promise that students have been screened.

## Voice

Friendly, clear, capable, and lightly playful. Explain an action before asking for it. Use ordinary student language and Nigerian naira formatting. Avoid forced slang, institutional language, unsupported trust claims, and invented campus partnerships.

Examples: “Find something for your next semester.” “Give it a new Korner.” “Choose your campus.” “Your listing is ready.” A transaction failure should state what happened and what the student can do next.

## Growth

Use Korner as the parent brand. Future descriptors such as Marketplace, Food, Services, or Communities use the same wordmark and symbol; they do not each require a new logo or a new signature color. Separate product navigation from the enduring identity.

## Current boundary

This phase delivers refined artwork and identity specifications for review. It does not implement the production token library, component system, product screen suite, backend, or payments. Phase 3 follows approval of the refined identity. User selection of a direction is recorded separately from approval of final artwork.
