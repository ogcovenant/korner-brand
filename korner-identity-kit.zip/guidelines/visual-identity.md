# Korner visual identity

Phase 2 · In the loop · v1.0 for review.

## The system

The identity combines an original three-loop symbol, the user's preferred lowercase **korner.** navbar wordmark, a hibiscus signature, Geist interface typography, and warm neutral space. The symbol is the social idea; the familiar word is its anchor.

The Phase 1 artwork remains in `public/logos/`. The refined Phase 2 artwork is separate in `public/brand/logos/`; use those files for subsequent work. Do not silently substitute the early C symbol or its hand-drawn wordmark.

## Refinement

The concept's crowded center is opened. Each repeated path is rotated by 120 degrees around the same 64-unit frame; round terminals retain the original friendly character. The dedicated small-size path increases separation at the center rather than merely shrinking the main drawing.

The wordmark preserves the actual navbar reference: Hanken Grotesk at weight 750 with −0.04em spacing and its period. Letter outlines are embedded in SVG. This is font-derived lettering, not a claim of a wholly original typeface. The symbol and currency outlines are authored geometry. Hanken's license and credit are included in the kit.

## Color

Hibiscus `#B52F52` is the enduring signature. Charcoal `#30272C` anchors light surfaces. Warm sand `#F0CFB3` is a restrained accent. The dark theme uses a rose action color `#F692AA` and a charcoal canvas `#211A20`. Detailed roles, OKLCH values, and pairing evidence are in `color-system.md` and `identity-contrast-report.json`.

Use mostly neutral space in task interfaces. A full hibiscus field is appropriate for brand moments. Do not add gradients or a rotating set of bright category colors. Brand hibiscus does not replace semantic error colors.

## Shape and composition

Brand layouts favor spacious type, clear alignment, and object-led content. Use moderate 8px controls and 12px containers as the working shape language; detailed production radius and spacing tokens belong to Phase 3. Pills suit compact labels rather than all containers.

The symbol may appear alone in a recognized Korner context. Establish the complete wordmark or horizontal lockup before asking a new audience to recognize the abstract mark by itself. Do not scatter detached loops as confetti or use them as unrelated UI icons.

## Photography and representation

Products are the main marketplace imagery. Use actual items, honest condition, natural light, and informative angles. Student photography should reflect contemporary African campus life without invented affiliations or clichés. The Phase 2 guide uses no borrowed product or student photography. The Phase 1 demo photos remain illustrative and require replacement before publication.

## Motion and meaning

Use restrained 180ms ease-out feedback and respect reduced motion. Keep the three loops together; movement should not alter the silhouette or imply payment success, verification, or activity without product evidence. No animation is required for recognition.

## Review artifacts

`review/korner-brand-identity.html` is the self-contained guide. `public/brand/proofs/` contains outlined vector and PNG logo, construction, and currency proofs. These are vector exports, not browser screenshots. Browser/device layout, app platform masks, and physical printing remain contextual checks before production release.
