# Korner / In the loop / Identity v1.0

Refined Phase 2 identity for review. The selected direction is C, paired with the navbar wordmark the user preferred. Final artwork approval is pending.

# Korner brand strategy

Phase 2 · In the loop · Identity v1.0 for review.

## Purpose

Connect the individual corners of campus into a useful shared world. Begin with buying, selling, and trading; retain room for student businesses, services, food, accommodation, events, communities, and financial services.

## Audience and position

Nigerian university students finding what they need from people around them. Korner should feel chosen by students, with the clarity and care expected when money changes hands. Campus proximity is the starting advantage; the identity must remain useful beyond university.

## Identity decisions

The user selected C — In the loop, superseding the Phase 1 recommendation of A. They also explicitly liked the Phase 1 navbar wordmark. The refined system combines the three-loop symbol with the bold lowercase **korner.** navbar treatment, including its tight spacing and trailing dot.

The interface type remains Geist. The wordmark is a fixed, outlined Hanken Grotesk 750 treatment; it is not replaced by live interface text. The signature color is hibiscus. Warm neutral surfaces keep everyday browsing calm.

## Core expression

**Your campus. Your Korner.** Keep the capitalization and two sentences. The dot is part of the visual wordmark; the product's written name remains **Korner**, without a mandatory trailing dot in prose.

Three loops keep their individual space around a shared center. They represent belonging and possibility without restricting the platform to shopping. Their geometry is a metaphor, not a verification badge or promise that students have been screened.

## Voice

Friendly, clear, capable, and lightly playful. Explain an action before asking for it. Use ordinary student language and Nigerian naira formatting. Avoid forced slang, institutional language, unsupported trust claims, and invented campus partnerships.

Examples: “Find something for your next semester.” “Give it a new Korner.” “Choose your campus.” “Your listing is ready.” A transaction failure should state what happened and what the student can do next.

## Growth

Use Korner as the parent brand. Future descriptors such as Marketplace, Food, Services, or Communities use the same wordmark and symbol; they do not each require a new logo or a new signature color. Separate product navigation from the enduring identity.

## Current boundary

This phase delivers refined artwork and identity specifications for review. It does not implement the production token library, component system, product screen suite, backend, or payments. Phase 3 follows approval of the refined identity. User selection of a direction is recorded separately from approval of final artwork.


---

# Korner visual identity

Phase 2 · In the loop · v1.0 for review.

## The system

The identity combines an original three-loop symbol, the user's preferred lowercase **korner.** navbar wordmark, a hibiscus signature, Geist interface typography, and warm neutral space. The symbol is the social idea; the familiar word is its anchor.

The Phase 1 artwork remains in `public/logos/`. The refined Phase 2 artwork is separate in `public/brand/logos/`; use those files for subsequent work. Do not silently substitute the early C symbol or its hand-drawn wordmark.

## Refinement

The concept's crowded center is opened. Each repeated path is rotated by 120 degrees around the same 64-unit frame; round terminals retain the original friendly character. The dedicated small-size path increases separation at the center rather than merely shrinking the main drawing.

The wordmark preserves the actual navbar reference: Hanken Grotesk at weight 750 with −0.04em spacing and its period. Letter outlines are embedded in SVG. This is font-derived lettering, not a claim of a wholly original typeface. The symbol and currency outlines are authored geometry. Hanken's license and credit are included in the kit.

## Color

Hibiscus `#B52F52` is the enduring signature. Charcoal `#30272C` anchors light surfaces. Warm sand `#F0CFB3` is a restrained accent. The dark theme uses a rose action color `#F692AA` and a charcoal canvas `#211A20`. Detailed roles, OKLCH values, and pairing evidence are in `color-system.md` and `identity-contrast-report.json`.

Use mostly neutral space in task interfaces. A full hibiscus field is appropriate for brand moments. Do not add gradients or a rotating set of bright category colors. Brand hibiscus does not replace semantic error colors.

## Shape and composition

Brand layouts favor spacious type, clear alignment, and object-led content. Use moderate 8px controls and 12px containers as the working shape language; detailed production radius and spacing tokens belong to Phase 3. Pills suit compact labels rather than all containers.

The symbol may appear alone in a recognized Korner context. Establish the complete wordmark or horizontal lockup before asking a new audience to recognize the abstract mark by itself. Do not scatter detached loops as confetti or use them as unrelated UI icons.

## Photography and representation

Products are the main marketplace imagery. Use actual items, honest condition, natural light, and informative angles. Student photography should reflect contemporary African campus life without invented affiliations or clichés. The Phase 2 guide uses no borrowed product or student photography. The Phase 1 demo photos remain illustrative and require replacement before publication.

## Motion and meaning

Use restrained 180ms ease-out feedback and respect reduced motion. Keep the three loops together; movement should not alter the silhouette or imply payment success, verification, or activity without product evidence. No animation is required for recognition.

## Review artifacts

`review/korner-brand-identity.html` is the self-contained guide. `public/brand/proofs/` contains outlined vector and PNG logo, construction, and currency proofs. These are vector exports, not browser screenshots. Browser/device layout, app platform masks, and physical printing remain contextual checks before production release.


---

# Korner logo guidelines

Phase 2 · In the loop · v1.0 for review. Artwork lives in `public/brand/logos/`; the complete inventory is `public/brand/logo-manifest.json`.

## Logo family

| Asset | Use |
| --- | --- |
| `korner-horizontal-primary.svg` | Preferred horizontal: hibiscus symbol, charcoal wordmark, hibiscus dot on a light surface |
| `korner-horizontal-brand.svg` | Single hibiscus horizontal lockup |
| `korner-symbol-brand.svg` | Standard standalone symbol |
| `korner-symbol-small-brand.svg` | Dedicated 16–23px symbol |
| `korner-wordmark-primary.svg` | Navbar treatment: charcoal name and hibiscus dot |
| `korner-wordmark-ink.svg` | Entire wordmark in charcoal |
| `korner-horizontal-tagline-primary.svg` | Parent lockup with outlined primary tagline |
| `korner-app-icon.svg` | Full-bleed 1024-square app icon master |
| `korner-app-icon-dark.svg` | Optional charcoal/rose app icon master |
| `*-preview.svg` | Rounded app icon previews only |

Each symbol, small symbol, wordmark, horizontal, and tagline lockup is also supplied in brand hibiscus, charcoal ink, white, dark-theme rose, and black monochrome versions. The primary two-color family is supplied separately. All files include explicit dimensions, a viewBox, and an accessible title. Lettering and tagline are paths, with no runtime font requirement.

## Clear space

Define **x = 16 units**, one quarter of the standard symbol's 64-unit square grid. Keep at least x clear on all sides of the symbol or complete lockup. For a 32px symbol, x is 8px. For the horizontal logo, calculate x from the 64-unit symbol embedded in the 370-unit-wide lockup: at 185px wide, x is 8px.

Measure outside the supplied SVG frame, not by trimming to the visible ink. Do not place text, images, borders, screen edges, or another mark in that zone. The wordmark-only file uses its 76-unit vertical frame as the reference: reserve 19 source units on each side. At 112px wide, that is approximately 7.4px.

App icons are an exception to external clear space: they have their own safe-area construction and platform mask. Do not add extra padding around an app icon master before platform submission.

## Minimum sizes

| Asset | Digital minimum | Print minimum |
| --- | --- | --- |
| Standard symbol | 24px square | 7mm square |
| Small symbol | 16px square; use only at 16–23px | Use standard print artwork |
| Wordmark | 112px wide | 28mm wide |
| Horizontal | 160px wide | 40mm wide |
| Horizontal with tagline | 280px wide | 70mm wide |

These are the final proposed v1.0 specifications, supported by vector/raster proofs. They are design limits, not evidence of a completed device or press trial. Confirm the intended screen density, substrate, and print process. Below 16px use a text label or another UI affordance rather than compressing the symbol further. Size the SVG proportionally; do not independently assign width and height.

## Approved backgrounds

Primary or hibiscus artwork: white or the approved light canvas. Charcoal ink: light canvas, white, or sand where measured contrast permits. White: hibiscus or approved dark charcoal. Rose: the approved dark canvas or dark surface. Black and white variants support single-color reproduction.

Do not use white on sand, rose on white, or hibiscus on charcoal. Do not place a logo directly over a busy photograph; supply a sufficiently large solid approved field and retain clear space. Use files provided for each context instead of applying arbitrary CSS filters.

## App icons

Use the 1024×1024 square master without pre-rounded corners. The artwork remains inside the central 70% square and fits a centered circular mask. Let the platform supply the final rounded, squircle, or circular crop. Rounded SVGs are presentation previews only. Raster PNGs are supplied in `public/brand/app-icons/`; preserve sRGB, opacity, and square dimensions.

The main app icon uses white on hibiscus in both ordinary interface themes. The optional dark icon is charcoal with a rose mark. Platform-specific asset packaging is outside this branding phase; validate masks on target devices before submission.

## Incorrect use

Do not rotate, stretch, redraw, outline, shadow, or gradient-fill the identity. Do not separate or recolor the three loops independently. Do not replace the wordmark with typed Geist or Hanken text. The period is part of the wordmark; do not remove it, enlarge it, or add a second one. Written prose still uses the name “Korner”.

Keep the symbol-to-wordmark ratio and spacing fixed. Do not attach a university crest, graduation cap, cart, pin, or verification tick. Do not use the logo as a seller trust badge.

## Accessibility and source

Use an appropriate image label such as `alt="Korner"` in a home link. If the same link includes visible “Korner” text, mark the duplicate image decorative with empty alt. Decorative repeat marks should not be announced. The SVG title is helpful but does not replace HTML image alternatives.

Generator: `scripts/make-identity.py`. The original symbol is authored path geometry. The user-chosen navbar wordmark is outlined from the locally supplied licensed Hanken font. Original authorship and licensing do not establish trademark availability; no clearance is claimed.


---

# Korner color system

Phase 2 · In the loop · v1.0. The user selected C. The source specification is `brand/identity.json`; this document and the JSON report are generated by `npm run check:identity-colors`.

Hibiscus is the signature, charcoal is the anchor, and warm sand is a restrained accent. Use roughly 80–90% neutral surfaces in task interfaces. Marketing can use a full hibiscus field. Do not turn all statuses hibiscus or add other bright accents.

Light mode: white labels on hibiscus. Dark mode: dark labels on rose. White also serves as a logo reverse on the dark canvas. The app icon keeps a stable hibiscus signature; an optional charcoal/rose icon is supplied.

Use `border` for controls on `background` or `surface`. It is not approved on `surfaceAlt`; use the main surface for form controls. `divider` is decorative and never the sole boundary of a control. `accent` uses `onAccent`. Status colors are foregrounds on neutral surfaces, accompanied by a word or icon; do not put white labels on those colors without a separate pairing check.

A focus ring uses the focus color with a 2px surface-colored gap. The pairings cover the ring against neutral backgrounds; preserve the gap when a control is colored. Disabled controls should use a visible label and disabled semantics rather than introducing an untested muted text/background pair.

54 pairings pass their stated targets. Body and control text target 4.5:1; non-text boundaries and focus target 3:1. Ratios are computed before rounding. This is color-pair evidence, not a complete WCAG conformance claim.

## Light mode

| Role | HEX | OKLCH |
| --- | --- | --- |
| primary | #B52F52 | oklch(52.14% 0.1705 10.26) |
| onPrimary | #FFFFFF | oklch(100.00% 0.0000 0.00) |
| primaryHover | #9E2546 | oklch(46.89% 0.1570 10.01) |
| primaryPressed | #87203C | oklch(42.00% 0.1382 9.69) |
| secondary | #3D2930 | oklch(30.75% 0.0318 356.40) |
| accent | #F0CFB3 | oklch(87.53% 0.0528 62.37) |
| onAccent | #30272C | oklch(28.48% 0.0159 343.66) |
| background | #F9F7F7 | oklch(97.77% 0.0021 17.20) |
| surface | #FFFFFF | oklch(100.00% 0.0000 0.00) |
| surfaceAlt | #F1ECEF | oklch(94.78% 0.0067 340.39) |
| text | #30272C | oklch(28.48% 0.0159 343.66) |
| muted | #70606A | oklch(50.78% 0.0254 340.15) |
| border | #95818C | oklch(62.50% 0.0290 343.72) |
| divider | #E5DCE0 | oklch(90.28% 0.0112 348.46) |
| focus | #7D1E3A | oklch(39.92% 0.1301 7.95) |
| success | #296447 | oklch(45.54% 0.0784 159.48) |
| warning | #805200 | oklch(47.86% 0.1024 72.16) |
| error | #B42318 | oklch(50.03% 0.1821 29.51) |

| Pair | Ratio | Target | Result |
| --- | --- | --- | --- |
| text / background | 13.55:1 | 4.5:1 | Pass |
| muted / background | 5.51:1 | 4.5:1 | Pass |
| secondary / background | 12.63:1 | 4.5:1 | Pass |
| success / background | 6.54:1 | 4.5:1 | Pass |
| warning / background | 6.30:1 | 4.5:1 | Pass |
| error / background | 6.16:1 | 4.5:1 | Pass |
| focus / background | 9.29:1 | 3:1 | Pass |
| text / surface | 14.46:1 | 4.5:1 | Pass |
| muted / surface | 5.88:1 | 4.5:1 | Pass |
| secondary / surface | 13.48:1 | 4.5:1 | Pass |
| success / surface | 6.98:1 | 4.5:1 | Pass |
| warning / surface | 6.72:1 | 4.5:1 | Pass |
| error / surface | 6.57:1 | 4.5:1 | Pass |
| focus / surface | 9.91:1 | 3:1 | Pass |
| text / surfaceAlt | 12.38:1 | 4.5:1 | Pass |
| muted / surfaceAlt | 5.04:1 | 4.5:1 | Pass |
| secondary / surfaceAlt | 11.54:1 | 4.5:1 | Pass |
| success / surfaceAlt | 5.98:1 | 4.5:1 | Pass |
| warning / surfaceAlt | 5.76:1 | 4.5:1 | Pass |
| error / surfaceAlt | 5.63:1 | 4.5:1 | Pass |
| focus / surfaceAlt | 8.49:1 | 3:1 | Pass |
| border / background | 3.39:1 | 3:1 | Pass |
| border / surface | 3.62:1 | 3:1 | Pass |
| onPrimary / primary | 6.01:1 | 4.5:1 | Pass |
| onPrimary / primaryHover | 7.48:1 | 4.5:1 | Pass |
| onPrimary / primaryPressed | 9.12:1 | 4.5:1 | Pass |
| onAccent / accent | 9.83:1 | 4.5:1 | Pass |

## Dark mode

| Role | HEX | OKLCH |
| --- | --- | --- |
| primary | #F692AA | oklch(77.08% 0.1231 4.90) |
| onPrimary | #301922 | oklch(24.83% 0.0392 355.35) |
| primaryHover | #FFAAC0 | oklch(82.66% 0.1031 2.70) |
| primaryPressed | #E77D99 | oklch(71.48% 0.1334 4.16) |
| secondary | #E1BCCB | oklch(83.16% 0.0466 351.83) |
| accent | #F0CFB3 | oklch(87.53% 0.0528 62.37) |
| onAccent | #30272C | oklch(28.48% 0.0159 343.66) |
| background | #211A20 | oklch(22.87% 0.0156 330.84) |
| surface | #2E242C | oklch(27.50% 0.0205 333.07) |
| surfaceAlt | #392D36 | oklch(31.40% 0.0231 335.07) |
| text | #FAF3F6 | oklch(97.04% 0.0084 349.24) |
| muted | #CDBAC5 | oklch(80.81% 0.0262 341.96) |
| border | #A58B9A | oklch(66.51% 0.0377 342.60) |
| divider | #4C3A47 | oklch(37.29% 0.0327 336.47) |
| focus | #F692AA | oklch(77.08% 0.1231 4.90) |
| success | #A5D8B7 | oklch(83.75% 0.0702 156.20) |
| warning | #F6CC86 | oklch(86.63% 0.0999 79.63) |
| error | #FFB4A8 | oklch(83.76% 0.0898 29.23) |

| Pair | Ratio | Target | Result |
| --- | --- | --- | --- |
| text / background | 15.58:1 | 4.5:1 | Pass |
| muted / background | 9.26:1 | 4.5:1 | Pass |
| secondary / background | 9.94:1 | 4.5:1 | Pass |
| success / background | 10.63:1 | 4.5:1 | Pass |
| warning / background | 11.27:1 | 4.5:1 | Pass |
| error / background | 10.01:1 | 4.5:1 | Pass |
| focus / background | 7.79:1 | 3:1 | Pass |
| text / surface | 13.68:1 | 4.5:1 | Pass |
| muted / surface | 8.13:1 | 4.5:1 | Pass |
| secondary / surface | 8.72:1 | 4.5:1 | Pass |
| success / surface | 9.33:1 | 4.5:1 | Pass |
| warning / surface | 9.89:1 | 4.5:1 | Pass |
| error / surface | 8.79:1 | 4.5:1 | Pass |
| focus / surface | 6.84:1 | 3:1 | Pass |
| text / surfaceAlt | 11.99:1 | 4.5:1 | Pass |
| muted / surfaceAlt | 7.13:1 | 4.5:1 | Pass |
| secondary / surfaceAlt | 7.65:1 | 4.5:1 | Pass |
| success / surfaceAlt | 8.18:1 | 4.5:1 | Pass |
| warning / surfaceAlt | 8.67:1 | 4.5:1 | Pass |
| error / surfaceAlt | 7.70:1 | 4.5:1 | Pass |
| focus / surfaceAlt | 6.00:1 | 3:1 | Pass |
| border / background | 5.48:1 | 3:1 | Pass |
| border / surface | 4.81:1 | 3:1 | Pass |
| onPrimary / primary | 7.46:1 | 4.5:1 | Pass |
| onPrimary / primaryHover | 9.13:1 | 4.5:1 | Pass |
| onPrimary / primaryPressed | 6.05:1 | 4.5:1 | Pass |
| onAccent / accent | 9.83:1 | 4.5:1 | Pass |

## Sources and handoff

Contrast method: [W3C WCAG contrast minimum](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html). HEX is authoritative; OKLCH is an sRGB conversion rounded for communication. Phase 3 will implement semantic CSS tokens from the approved specification. No marketplace token library is implemented in Phase 2.


---

# Korner typography

Phase 2 · In the loop · v1.0 for review.

## Roles

**Geist** is the interface and editorial family. Use a single variable WOFF2 face for headings, body, labels, buttons, and numerals. The system favors legibility and lets the hibiscus identity and symbol provide distinction.

**korner.** is fixed logo artwork based on the navbar lettering the user explicitly liked: Hanken Grotesk 750, −0.04em spacing, with the trailing period. Its SVG contains outlines. Hanken is not a second interface font, and a live font rendering is not a substitute for the approved SVG.

**Korner Currency** is an authored one-glyph ₦ companion. The supplied Geist subsets do not contain U+20A6. Four tiny WOFF2 files supply the missing symbol at weights 400, 500, 600, and 700. Geist's font software is unmodified. The companion uses the same 1000-unit frame and vertical metrics, a 710-unit cap height, and a 660-unit advance. Its source geometry is in `scripts/make-identity.py`.

## Scale

| Role | Mobile / desktop | Line height | Weight | Tracking |
| --- | --- | --- | --- | --- |
| Display | 40 / 64px | 1.05 | 600 | −0.03em |
| Page title | 32 / 40px | 1.15 | 600 | −0.025em |
| Section heading | 24 / 28px | 1.25 | 600 | −0.02em |
| Card title | 16 / 18px | 1.4 | 500 | 0 |
| Body | 16 / 16px | 1.6 | 400 | 0 |
| Secondary | 14 / 14px | 1.5 | 400 | 0 |
| Label / button | 14 / 14px | 1.4 | 600 | 0 |
| Caption | 12 / 12px | 1.5 | 500 | 0.01em |
| Price | 20 / 24px | 1.2 | 600 | −0.02em |

These are product typography specifications. The brand guide can use larger display specimens; its implementation does not establish a production component library. Keep interface labels in sentence case. Reserve 700 for rare emphasis. Do not apply negative tracking to paragraph text.

## Readability and numbers

Default body copy is 16px/1.6. Limit long-form measures to 65–75 characters. Use 14px for genuinely secondary content and 12px for supplemental captions, never as the only explanation of a critical action. Support zoom and wrapping; do not truncate prices or campus names without a way to read them.

Use `font-variant-numeric: tabular-nums` for price lists, balances, and comparisons. Format prices with `Intl.NumberFormat('en-NG', { style: 'currency', currency: 'NGN', maximumFractionDigits: 0 })` when fractional precision is unnecessary. Financial products must separately define their precision requirements. Example prices in the guide are illustrative.

## Font loading proposal

```css
font-family: "Geist", "Korner Currency", Arial, sans-serif;
font-synthesis: none;
font-variant-numeric: tabular-nums; /* prices and comparable figures */
```

Self-host Geist Latin as variable WOFF2 with `font-display: swap`. Preload only the face required above the fold. Add the extended Latin subset with a unicode range for content needing accented Latin characters. Each currency face uses `unicode-range: U+20A6`, so it is requested only where ₦ is present. The four companion weights are static; do not request unsupported intermediate currency weights.

The guide's scoped CSS demonstrates loading. Exporting semantic production typography tokens is Phase 3 work. The font files and licenses are included in the kit. On a slow connection, system fallback remains possible until fonts load; glyph coverage is verified but browser/device alignment still needs contextual testing.

## Proof and attribution

`public/brand/proofs/type-currency.svg` draws each currency glyph from its actual generated font file alongside Geist figures at the same weight. The WOFF2 cmaps, horizontal/vertical metrics, and glyph contours are checked directly. Raster PNG proofs are rendered from that SVG; these are not browser screenshots.

Primary sources: [Geist](https://github.com/vercel/geist-font) and [Hanken Grotesk](https://github.com/marcologous/hanken-grotesk). Their supplied SIL Open Font License notices are retained in the kit. The companion is original project artwork generated as font data; no third-party naira glyph has been copied.
