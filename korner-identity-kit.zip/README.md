# Korner identity kit v1.0

Phase 2 artwork for review. Use the supplied SVGs rather than retyping the wordmark. The final proposed system pairs the In the loop symbol with the lowercase korner. navbar wordmark.

Start with guidelines/logo-guidelines.md and guidelines/color-system.md. Full-bleed square app PNGs/SVGs are masters; rounded previews are presentation only. The guide HTML is provided separately to keep this archive portable and nonrecursive.

Fonts: Geist (interface), licensed Hanken-derived outlined logo, and original Korner Currency naira companion. Included upstream licenses are preserved. No trademark, browser/device, app-platform, or print-process clearance is implied.

Sources reproduce the vector and currency assets with Python 3 + fontTools/WOFF2 support. Node builds use the supplied files. No product screens, backend, or production token library are included.
